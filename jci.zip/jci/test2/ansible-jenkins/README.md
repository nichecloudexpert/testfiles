# ansible-jenkins

Ansible Playbook for provisioning a Jenkins CI server behind an Nginx proxy.

Tested on Ubuntu 18.04 x64.

### Usage

```
ansible-playbook -i myserver.example.com, jenkins.yml
```
